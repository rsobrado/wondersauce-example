<?php
/**
 * @package wondersauce-example
 * @version 1.0.0
 */
/*
Plugin Name: Wondersauce Example
Description: Wondersauce Example (title,description,image)
Author: Roger Sobrado
Version: 1.0.0
*/
function get_items() {
	$args = [
		'numberposts' => 99999,
		'post_type' => 'post' /* pages || custom-type */
	];

	$posts = get_posts($args);
	$data = [];
	$i = 0;

	foreach($posts as $post) {
		$data[$i]['id'] = $post->ID;
		$data[$i]['title'] = $post->post_title;
		$data[$i]['content'] = $post->post_content;
		$data[$i]['featured_image']= get_the_post_thumbnail_url($post->ID, 'large');
		$i++;
	}
  return $data;
}

/* custom route /api/wondersauce-example */
add_action('rest_api_init', function() {
	register_rest_route('api', 'wondersauce-example', [
		'methods' => 'GET',
		'callback' => 'get_items',
  ]);  
});
